/**
 * Regras de domínio do Safe Student: permissões, escopo de alunos e sequência de entrada/saída.
 */
function normalizeToken(value) {
  return String(value || '').trim().toUpperCase();
}

function canRegisterAttendance(role) {
  return ['PORTARIA', 'GESTAO'].includes(role);
}

function canManageSchool(role) {
  return ['GESTAO'].includes(role);
}

function canViewAudit(role) {
  return ['GESTAO'].includes(role);
}

function canMessageRole(fromRole, toRole) {
  const rules = {
    RESPONSAVEL: ['GESTAO', 'PORTARIA'],
    PORTARIA: ['RESPONSAVEL', 'GESTAO'],
    GESTAO: ['RESPONSAVEL', 'PORTARIA'],
  };
  return Boolean(rules[fromRole]?.includes(toRole));
}

function allowedStudentIds(user, db) {
  if (!user) return [];
  if (user.role === 'RESPONSAVEL') return (user.studentIds || []).filter(id => db.students.some(s => s.id === id && s.status === 'ATIVO'));
  if (['PORTARIA', 'GESTAO'].includes(user.role)) {
    return db.students.filter((s) => s.status === 'ATIVO').map((s) => s.id);
  }
  return [];
}

function validateAttendanceSequence(records, type) {
  const sorted = [...records].sort((a, b) => a.timestamp.localeCompare(b.timestamp));
  const last = sorted[sorted.length - 1];
  if (type === 'ENTRADA' && last && last.type === 'ENTRADA') {
    return { ok: false, error: 'Já existe entrada pendente para este aluno hoje.' };
  }
  if (type === 'SAIDA' && (!last || last.type !== 'ENTRADA')) {
    return { ok: false, error: 'Não há entrada válida para registrar saída.' };
  }
  return { ok: true };
}

function attendanceRate(records, schoolDays = 20, dayKey = (value) => String(value || '').slice(0, 10)) {
  const uniqueDays = new Set(
    records
      .filter((r) => r.type === 'ENTRADA')
      .map((r) => dayKey(r.timestamp))
      .filter(Boolean),
  );
  return schoolDays > 0 ? Math.min(100, Math.round((uniqueDays.size / schoolDays) * 100)) : 0;
}

module.exports = {
  normalizeToken,
  canRegisterAttendance,
  canManageSchool,
  canViewAudit,
  canMessageRole,
  allowedStudentIds,
  validateAttendanceSequence,
  attendanceRate,
};
